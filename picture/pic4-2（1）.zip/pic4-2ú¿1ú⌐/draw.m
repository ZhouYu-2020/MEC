length = 7

%all_twait = importfile('.\all+twait.xlsx', 'Sheet1', [2, length]);
%all_twait_30_UEs = importfile('.\all+twait+30_UEs.xlsx', 'Sheet1', [2, length]);
%local = importfile('.\local.xlsx', 'Sheet1', [2, length]); 
%local_30 = importfile('.\local+30_UEs.xlsx', 'Sheet1', [2, length]); 
%mec_twait = importfile('.\mec+twait.xlsx', 'Sheet1', [2, length]); 
load matlab.mat


Step = [0.005,0.010,0.020,0.030,0.040,0.050]

plot(Step,local,'-o','Color',[rand rand rand])
hold on
plot(Step,local_30,'-o','Color',[rand rand rand])
hold on
plot(Step,mec_twait,'-x','Color',[rand rand rand])
hold on
plot(Step,mec_twait_30UEs,'-x','Color',[rand rand rand])
hold on

plot(Step,all_twait,'-*','Color',[rand rand rand])
hold on
plot(Step,all_twait_30UEs,'-*','Color',[rand rand rand])
hold on

xlabel('the time delay threshold t^{max} (s)')
ylabel('the total of system energry comsumption (J)')
legend('Non MEC (UEs=15)','Non MEC (UEs=30)','Stand alone MEC (UEs=15)','Stand alone MEC (UEs=30)','Proposed EVT learning (UEs=15)','Proposed EVT learning (UEs=30)')
%figure



